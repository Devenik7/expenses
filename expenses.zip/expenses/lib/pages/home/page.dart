import 'package:expenses/pages/dashboard/page.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';

import 'package:expenses/base.dart';
import 'package:expenses/pages/profile/page.dart';
import 'package:expenses/pages/home/controller.dart';

class Home extends AppPage {
  static String routeName = '/home';

  static void start({bool offAll = true}) =>
      (offAll ? navigateOffAll : navigateTo)(routeName);

  final controller = Get.put(HomeController());

  @override
  Widget? get titleWidget {
    return Obx(
      () => FadeFromLeft(
        child: Text(
          controller.activeItem.title,
          key: ValueKey(controller.activeItem.title),
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  @override
  double get titleSpacing => 16;

  Widget get activeTab {
    switch (controller.bottomBarItems[controller.selectedTab.value].key) {
      case TabKey.dashboard:
        return Dashboard();
      case TabKey.profile:
        return Profile();
    }
  }

  @override
  Widget? get body {
    return Obx(() {
      return FadeFromLeft(
        position: Tween<Offset>(begin: Offset(0.05, 0), end: Offset(0, 0)),
        child: activeTab,
      );
    });
  }

  @override
  Widget? get fab => FloatingActionButton(
        onPressed: controller.onAddExpenseTap,
        child: Icon(Icons.post_add_rounded),
        splashColor: Colors.deepOrange,
      );

  @override
  FloatingActionButtonLocation? get fabLocation =>
      FloatingActionButtonLocation.centerDocked;

  @override
  Widget? get bottomBar {
    return Obx(() {
      return AppBottomBar(
        selected: controller.selectedTab.value,
        onItemTap: controller.onTabItemTap,
        items: controller.bottomBarItems,
      );
    });
  }
}
