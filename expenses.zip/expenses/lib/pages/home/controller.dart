import 'package:expenses/pages/expense/add_expense/page.dart';
import 'package:expenses/services/popup.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';

import 'package:expenses/base.dart';

enum TabKey { dashboard, profile }

class HomeController extends GetxController {
  var selectedTab = 0.obs;

  void onTabItemTap(int index) => selectedTab.value = index;

  BottomBarItem get activeItem => bottomBarItems[selectedTab.value];

  List<BottomBarItem> get bottomBarItems {
    return [
      BottomBarItem(
          key: TabKey.dashboard,
          icon: Icons.auto_graph_rounded,
          activeIcon: Icons.auto_graph_sharp,
          title: 'Dashboard'),
      BottomBarItem(
          key: TabKey.profile,
          icon: Icons.person_outline_rounded,
          activeIcon: Icons.person_rounded,
          title: 'Profile'),
    ];
  }

  void onAddExpenseTap() async {
    if (await AddExpense.start() ?? false) showSnack('Success');
  }
}
