import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:expenses/base.dart';

class Expense extends BaseFirestoreModel {
  final String name;
  final String category;
  final double price;
  final String payer;
  final String paymentMode;
  final String owner;
  final bool recurring;
  final bool vital;

  Expense({
    required this.name,
    required this.category,
    required this.price,
    required this.payer,
    required this.paymentMode,
    required this.owner,
    required this.recurring,
    required this.vital,
    required String uid,
    required Timestamp createdAt,
    required String createdBy,
    required bool active,
  }) : super(
          uid: uid,
          createdAt: createdAt,
          createdBy: createdBy,
          active: active,
        );

  Expense.createSelf(String name, String category, double price,
      String paymentMode, bool recurring, bool vital)
      : this(
          name: name,
          category: category,
          price: price,
          payer: Auth.uid,
          paymentMode: paymentMode,
          owner: Auth.uid,
          recurring: recurring,
          vital: vital,
          uid: '',
          createdAt: Timestamp.now(),
          createdBy: Auth.uid,
          active: true,
        );

  Expense copyWith({
    String? name,
    String? category,
    double? price,
    String? payer,
    String? paymentMode,
    String? owner,
    bool? recurring,
    bool? vital,
    String? uid,
    Timestamp? createdAt,
    String? createdBy,
    bool? active,
  }) {
    return Expense(
      name: name ?? this.name,
      category: category ?? this.category,
      price: price ?? this.price,
      payer: payer ?? this.payer,
      paymentMode: paymentMode ?? this.paymentMode,
      owner: owner ?? this.owner,
      recurring: recurring ?? this.recurring,
      vital: vital ?? this.vital,
      uid: uid ?? this.uid,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
      active: active ?? this.active,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'category': category,
      'price': price,
      'payer': payer,
      'paymentMode': paymentMode,
      'owner': owner,
      'recurring': recurring,
      'vital': vital,
      ...super.toMap(),
    };
  }

  factory Expense.fromMap(Map<String, dynamic> map, String uid) {
    return Expense(
      name: map['name'],
      category: map['category'],
      price: map['price'],
      payer: map['payer'],
      paymentMode: map['paymentMode'],
      owner: map['owner'],
      recurring: map['recurring'],
      vital: map['vital'],
      uid: uid,
      createdAt: map['createdAt'],
      createdBy: map['createdBy'],
      active: map['active'],
    );
  }

  @override
  BaseFirestoreModel copyWithUid(String uid) => this.copyWith(uid: uid);
}
