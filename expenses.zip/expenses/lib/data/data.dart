export 'users.dart';
export 'payment_modes.dart';
export 'expenses.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:expenses/base.dart';

abstract class BaseFirestoreService<T extends BaseFirestoreModel> {
  CollectionReference get ref;

  T construct(Map<String, dynamic> map, String uid);

  Future<T?> get(String uid) async {
    try {
      var response = await ref.doc(uid).get();
      return response.exists
          ? construct(response.data() as Map<String, dynamic>, uid)
          : null;
    } catch (_, __) {
      Logger.log(_, __);
      return null;
    }
  }

  Future<T?> create(T model) async {
    try {
      var response = await ref.add(model.toMap());
      return model.copyWithUid(response.id) as T;
    } catch (_, __) {
      Logger.log(_, __);
      return null;
    }
  }
}
