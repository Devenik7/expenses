import 'package:expenses/resources/palette.dart';
import 'package:expenses/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class PageMixin {
  T? getArgument<T>(String key, [T? defaultVal]) {
    return tryCatcher(() {
      dynamic value = Get.arguments['arguments'][key];
      return value == null ? defaultVal : value as T;
    }, defaultVal);
  }

  String get title => '';

  Widget? get titleWidget => null;

  Widget? get leading => null;

  List<Widget> get actions => [];

  double get titleSpacing => 0;

  double get toolbarHeight => kToolbarHeight;

  PreferredSizeWidget? get appBar => AppBar(
        title: titleWidget ?? Text(title),
        leading: leading,
        actions: actions,
        backgroundColor: Colors.transparent,
        foregroundColor: Palette.accent,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.dark.copyWith(
          statusBarColor: Colors.transparent,
        ),
        centerTitle: false,
        titleSpacing: titleSpacing,
        toolbarHeight: toolbarHeight,
      );

  Widget? get body => null;

  Widget? get fab => null;

  FloatingActionButtonLocation? get fabLocation => null;

  Widget? get bottomBar => null;

  bool get resizeToAvoidBottomInset => true;
}

class AppPage extends StatelessWidget with PageMixin {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar,
      body: body,
      floatingActionButton: fab,
      floatingActionButtonLocation: fabLocation,
      bottomNavigationBar: bottomBar,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
    );
  }
}

class StatefulAppPage extends StatefulWidget {
  @override
  StatefulAppPageState createState() => StatefulAppPageState();
}

class StatefulAppPageState<T extends StatefulAppPage> extends State<T>
    with PageMixin {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar,
      body: body,
      floatingActionButton: fab,
      floatingActionButtonLocation: fabLocation,
      bottomNavigationBar: bottomBar,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
    );
  }
}
