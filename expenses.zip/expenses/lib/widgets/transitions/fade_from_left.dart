import 'package:flutter/widgets.dart';

class FadeFromLeft extends StatelessWidget {
  final Widget child;
  final Duration duration;
  final Tween<double>? opacity;
  final Tween<Offset>? position;

  final kDefaultOpacityTween = Tween<double>(begin: 0, end: 1);
  final kDefaultPositionTween =
      Tween<Offset>(begin: Offset(1, 0), end: Offset(0.0, 0.0));

  FadeFromLeft({
    required this.child,
    this.duration = const Duration(milliseconds: 200),
    this.opacity,
    this.position,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: duration,
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeOutCubic,
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(
          opacity: (opacity ?? kDefaultOpacityTween).animate(animation),
          child: SlideTransition(
            child: child,
            position: (position ?? kDefaultPositionTween).animate(animation),
          ),
        );
      },
      layoutBuilder: (curr, prev) => Stack(
        alignment: Alignment.centerLeft,
        children: <Widget>[...prev, if (curr != null) curr],
      ),
      child: child,
    );
  }
}
