import 'package:expenses/base.dart';
import 'package:expenses/services/popup.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class AddExpenseController extends GetxController {
  final name = TextEditingController();
  final category = TextEditingController();
  final price = TextEditingController();
  final paymentMode = TextEditingController();
  final recurring = FormFieldController<bool>();
  final vital = FormFieldController<bool>(value: true);

  Validation validateFields() {
    if (name.text.isNullOrEmpty)
      return Validation.error('Give a name to this Expense first !!!');
    if (category.text.isNullOrEmpty)
      return Validation.error('What Category does this Expense belong to ???');
    if (price.text.isNullOrEmpty || !price.text.isNum)
      return Validation.error('Price must be a valid number !!!');
    if (paymentMode.text.isNullOrEmpty)
      return Validation.error('What mode did you use to pay for this ???');

    return Validation.success();
  }

  var submitting = false.obs;

  void onSubmit() async {
    if (submitting.isTrue) return;

    var validation = validateFields();
    if (validation.isError) {
      showSnack(validation.message, color: Palette.error);
      return;
    }

    submitting.value = true;

    var expense = await ExpenseService.instance.create(Expense.createSelf(
      name.text,
      category.text,
      double.parse(price.text),
      paymentMode.text,
      recurring.value ?? false,
      vital.value ?? false,
    ));

    expense != null
        ? Get.back(result: true)
        : showSnack('Failed to submit Expense. Try Again',
            color: Palette.error);

    submitting.value = false;
  }
}
