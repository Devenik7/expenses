import 'package:expenses/pages/home/controller.dart';
import 'package:expenses/resources/palette.dart';
import 'package:flutter/material.dart';

class BottomBarItem {
  final TabKey key;
  final IconData icon;
  final IconData? activeIcon;
  final String title;

  BottomBarItem({
    required this.key,
    required this.icon,
    this.activeIcon,
    required this.title,
  });
}

class AppBottomBar extends StatelessWidget {
  final List<BottomBarItem> items;
  final int selected;
  final void Function(int) onItemTap;
  final double height;

  final Duration animDuration = Duration(milliseconds: 250);
  final Curve animCurve = Curves.easeOutCubic;

  AppBottomBar({
    required this.items,
    this.selected = 0,
    required this.onItemTap,
    this.height = 56,
  });

  Widget buildMiddleItem() => Expanded(child: SizedBox(height: height));

  Widget buildItem(int index) {
    var item = items[index];

    var color = selected == index ? Palette.accent : Palette.grey;

    Widget icon() =>
        Icon((selected == index ? item.activeIcon : item.icon) ?? item.icon,
            color: color);

    Widget text() => AnimatedOpacity(
          opacity: selected == index ? 1 : 0,
          duration: animDuration,
          child: AnimatedSize(
            duration: animDuration,
            curve: animCurve,
            child: SizedBox(
              width: selected == index ? null : 0,
              child: FittedBox(
                child: Text(
                  item.title,
                  style: TextStyle(fontWeight: FontWeight.bold, color: color),
                ),
              ),
            ),
          ),
        );

    return Expanded(
      child: SizedBox(
        height: height,
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () => onItemTap(index),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [icon(), text()],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: CircularNotchedRectangle(),
      child: Row(
        children: List.generate(items.length, (i) => buildItem(i))
          ..insert(items.length >> 1, buildMiddleItem()),
      ),
    );
  }
}
