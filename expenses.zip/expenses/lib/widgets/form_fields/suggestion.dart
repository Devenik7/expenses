import 'package:expenses/base.dart';
import 'package:expenses/widgets/app_errors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SuggestionFormField<T> extends AppFormField<T> {
  final EdgeInsets? margin;
  final List<SearchableFormOption<T>> suggestions;

  SuggestionFormField({
    Key? key,
    required String label,
    required this.suggestions,
    FormFieldController<T>? controller,
    FormFieldChangeCallback<T>? onChange,
    this.margin = const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
  }) : super(
          key: key,
          label: label,
          controller: controller,
          onChange: onChange,
        );

  @override
  SuggestionFormFieldState<T> createState() => SuggestionFormFieldState<T>();
}

class SuggestionFormFieldState<T> extends AppFormFieldState<T> {
  @override
  SuggestionFormField<T> get widget => super.widget as SuggestionFormField<T>;

  void onTap() async {
    var value = await SuggestionSelectionPage.start<T>(
      title: widget.label,
      suggestions: widget.suggestions,
      answer: effectiveController?.value,
    );
    if (value != null) {
      widget.onChange?.call(value);
      didChange(value);
    }
  }

  Widget get label {
    return Text(
      widget.label!,
      style: TextStyle(
        fontSize: hasAnswer ? 12 : 16,
        color: Palette.greyDarker,
      ),
    );
  }

  Widget get answer {
    if (effectiveController?.value == null) return SizedBox.shrink();

    List<SearchableFormOption<T>> selected = widget.suggestions
        .where((suggestion) => suggestion.value == effectiveController!.value)
        .toList();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: selected.length == 0
          ? Text('Select')
          : selected[0].build(false, () {}),
    );
  }

  Widget get clearIcon {
    if (!hasAnswer) return SizedBox.shrink();
    return GestureDetector(
      onTap: clear,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Icon(Icons.cancel_outlined, size: 16, color: Palette.error),
      ),
    );
  }

  Widget get dropdown =>
      Icon(Icons.arrow_drop_down_rounded, color: Palette.accent, size: 32);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: widget.margin,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.translucent,
        child: Container(
          padding: hasAnswer ? null : const EdgeInsets.fromLTRB(10, 8, 8, 8),
          decoration: hasAnswer
              ? null
              : BoxDecoration(
                  border: Border.all(color: Palette.grey),
                  borderRadius: BorderRadius.circular(6),
                ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [label, answer],
                ),
              ),
              clearIcon,
              dropdown,
            ],
          ),
        ),
      ),
    );
  }
}

class SuggestionSelectionPage<T> extends StatefulAppPage {
  @override
  SuggestionSelectionPageState<T> createState() =>
      SuggestionSelectionPageState<T>();

  static String routeName = '/suggestion-selection';

  static Future<T?> start<T>({
    String? title,
    required List<SearchableFormOption> suggestions,
    T? answer,
  }) =>
      navigateTo<T>(routeName, arguments: {
        'title': title,
        'suggestions': suggestions,
        'answer': answer,
      });
}

class SuggestionSelectionPageState<T>
    extends StatefulAppPageState<SuggestionSelectionPage<T>> {
  TextEditingController queryController = TextEditingController(text: '');

  @override
  void initState() {
    super.initState();
    queryController.addListener(() => setState(() {}));
  }

  List<SearchableFormOption<T>> get suggestions =>
      getArgument<List<SearchableFormOption<T>>>('suggestions', [])!;

  T? get answer => getArgument<T>('answer');

  @override
  String get title => getArgument<String>('title', 'Pick one')!;

  Widget get search {
    return AppTextFormField(
      hint: 'Search by typing here ...',
      controller: queryController,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
    );
  }

  Widget get options {
    List<SearchableFormOption<T>> filteredOptions = queryController.text.isEmpty
        ? suggestions
        : suggestions
            .where((option) => option.validate(queryController.text))
            .toList();

    return filteredOptions.length == 0
        ? AppError(title: 'No Options for found this query')
        : Wrap(
            runSpacing: 10,
            spacing: 10,
            children: List.generate(
              filteredOptions.length,
              (i) => filteredOptions[i].build(
                  answer == filteredOptions[i].value,
                  () => Get.back<T>(result: filteredOptions[i].value)),
            ),
          );
  }

  Widget get content {
    return Expanded(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
        physics: AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        child: options,
      ),
    );
  }

  @override
  Widget? get body {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [search, content],
    );
  }
}
