import 'dart:async';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:expenses/pages/config/page.dart';
import 'package:expenses/pages/login/page.dart';
import 'package:expenses/services/auth.dart';

class SplashController extends GetxController {
  late StreamSubscription<User?> subscription;

  void checkAuthStatus() {
    subscription = Auth.stateChanges
        .listen((user) => (user != null ? Config.start : Login.start)());
  }

  @override
  void onReady() {
    super.onReady();
    Future.delayed(Duration(seconds: 2), checkAuthStatus);
  }

  @override
  void onClose() async {
    await subscription.cancel();
    super.onClose();
  }
}
