import 'package:expenses/pages/add_family/page.dart';
import 'package:expenses/pages/config/page.dart';
import 'package:expenses/pages/expense/add_expense/page.dart';
import 'package:expenses/widgets/form_fields/suggestion.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:expenses/pages/home/page.dart';
import 'package:expenses/pages/login/page.dart';
import 'package:expenses/pages/splash/page.dart';
import 'package:expenses/firebase_options.dart';
import 'package:expenses/base.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(GetMaterialApp(
    theme: ThemeData(
      colorScheme: ColorScheme.light(
        primary: Palette.accent,
        secondary: Palette.accent,
        onSecondary: Colors.white,
      ),
      toggleableActiveColor: Palette.accent,
      splashColor: Palette.accent.withOpacity(0.3),
      highlightColor: Palette.accent.withOpacity(0.1),
    ),
    debugShowCheckedModeBanner: false,
    initialRoute: Splash.routeName,
    getPages: [
      GetPage(name: Splash.routeName, page: () => Splash()),
      GetPage(name: Login.routeName, page: () => Login()),
      GetPage(name: Config.routeName, page: () => Config()),
      GetPage(name: AddFamily.routeName, page: () => AddFamily()),
      GetPage(name: Home.routeName, page: () => Home()),
      GetPage(name: AddExpense.routeName, page: () => AddExpense()),
      GetPage(
          name: SuggestionSelectionPage.routeName,
          page: () => SuggestionSelectionPage()),
    ],
  ));
}
