import 'package:flutter/widgets.dart';

import 'package:expenses/base.dart';

class FamilyTile extends StatelessWidget {
  final EdgeInsets? margin;

  FamilyTile({
    this.margin = const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  });

  Widget get loader {
    return Container(
      padding: EdgeInsets.all(24),
      margin: margin,
      decoration: BoxDecoration(
          color: Palette.greyLightest, borderRadius: BorderRadius.circular(12)),
      child: CircularLoader(),
    );
  }

  Widget buildContent(List<String> family) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(
          color: Palette.greyLightest, borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          SectionHeader(title: 'Your Family'),
          ListView.builder(
            shrinkWrap: true,
            itemCount: family.length,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (_, i) => Text(family[i]),
          ),
        ],
      ),
    );
  }

  Widget get empty {
    return Container(
      padding: EdgeInsets.all(24),
      margin: margin,
      decoration: BoxDecoration(
          color: Palette.greyLightest, borderRadius: BorderRadius.circular(12)),
      child: Text('You haven\'t added added any family members',
          textAlign: TextAlign.center),
    );
  }

  Future<List<String>> fetchFamily() async {
    return Future.delayed(
        Duration(seconds: 3), () => ['Person 1', 'Person 2', 'Person 3']);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<String>>(
        future: fetchFamily(),
        builder: (_, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              return loader;
            default:
              return snapshot.data == null
                  ? empty
                  : buildContent(snapshot.data!);
          }
        });
  }
}
