export 'expense.dart';
export 'payment_mode.dart';
export 'user.dart';

import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/widgets.dart';

@mustCallSuper
abstract class BaseFirestoreModel {
  final String uid;
  final Timestamp createdAt;
  final String createdBy;
  final bool active;

  BaseFirestoreModel({
    required this.uid,
    required this.createdAt,
    required this.createdBy,
    required this.active,
  });

  // Do not set uid in the toMap since it is not actually part of the Firestore doc
  @mustCallSuper
  Map<String, dynamic> toMap() =>
      {'createdAt': createdAt, 'createdBy': createdBy, 'active': active};

  @override
  String toString() => json.encode(toMap());

  BaseFirestoreModel copyWithUid(String uid);
}
