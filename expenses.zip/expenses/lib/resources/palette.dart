import 'package:flutter/material.dart';

class Palette {
  static Color accent = Colors.deepOrange.shade700;

  static Color greyDarker = Colors.grey.shade700;
  static Color greyDark = Colors.grey.shade600;
  static Color grey = Colors.grey;
  static Color greyLight = Colors.grey.shade400;
  static Color greyLighter = Colors.grey.shade300;
  static Color greyLightest = Colors.grey.shade200;

  static Color btnActive = accent;
  static Color btnDisabled = greyLighter;

  static Color success = Colors.green.shade800;
  static Color error = Colors.red.shade900;
  static Color warning = Colors.orange.shade700;
}
