import 'package:intl/intl.dart';

extension DateTimeUtils on DateTime {
  String format(String pattern) => DateFormat(pattern).format(this);
}
