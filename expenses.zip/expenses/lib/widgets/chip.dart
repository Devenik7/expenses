import 'package:flutter/material.dart';

class AppChip extends StatelessWidget {
  final VoidCallback? onTap;
  final bool active;
  final Color color;
  final IconData? icon;
  final String label;
  final String badge;

  const AppChip({
    Key? key,
    this.onTap,
    this.active = false,
    required this.color,
    this.icon,
    required this.label,
    this.badge = '',
  }) : super(key: key);

  Widget get iconWidget {
    if (icon == null) return SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(4),
      child: Icon(icon, color: active ? Colors.white : color, size: 24),
    );
  }

  Widget get labelWidget {
    return Container(
      padding: const EdgeInsets.only(left: 4, right: 8),
      child: Text(label,
          style: TextStyle(color: active ? Colors.white : color, fontSize: 16)),
    );
  }

  // TODO - This doesnt look good for all cases
  Widget get badgeWidget {
    if (badge.isEmpty) return SizedBox.shrink();
    return AnimatedContainer(
      duration: Duration(milliseconds: 250),
      margin: const EdgeInsets.fromLTRB(2, 2, 2, 2),
      padding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
      constraints: BoxConstraints(minWidth: 32),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(4), bottomRight: Radius.circular(4)),
        color: color,
      ),
      child: Center(
        child: Text(
          badge,
          style: TextStyle(color: Colors.white, fontSize: 12),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? color : Colors.white,
      borderRadius: BorderRadius.circular(6),
      child: InkWell(
        borderRadius: BorderRadius.circular(6),
        splashColor: color.withOpacity(0.3),
        highlightColor: color.withOpacity(0.1),
        onTap: onTap,
        child: AnimatedContainer(
          height: 34,
          duration: Duration(milliseconds: 250),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: color),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [iconWidget, labelWidget, badgeWidget],
          ),
        ),
      ),
    );
  }
}
