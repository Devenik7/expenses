import 'package:get/get.dart';

Future<T?> navigateTo<T>(String routeName, {dynamic arguments}) async {
  try {
    var result = await Get.toNamed(
      routeName,
      arguments: {
        'arguments': arguments,
      },
    );
    return result == null ? null : (result as T);
  } catch (_) {
    return null;
  }
}

Future<T?> navigateOffAll<T>(String routeName, {dynamic arguments}) async {
  try {
    var result = await Get.offAllNamed(
      routeName,
      arguments: {
        'arguments': arguments,
      },
    );
    return result == null ? null : (result as T);
  } catch (_) {
    return null;
  }
}
