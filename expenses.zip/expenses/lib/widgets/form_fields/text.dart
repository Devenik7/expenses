import 'package:expenses/base.dart';
import 'package:flutter/material.dart';

class AppTextFormField extends StatelessWidget {
  final String? label;
  final String? hint;
  final TextEditingController? controller;
  final FormFieldChangeCallback<String>? onChange;
  final EdgeInsets? margin;
  final TextInputType? keyboardType;

  AppTextFormField({
    Key? key,
    this.label,
    this.hint,
    this.margin = const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    this.controller,
    this.onChange,
    this.keyboardType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: TextFormField(
        cursorHeight: 24,
        controller: controller,
        onChanged: onChange,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          isDense: true,
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
          ),
        ),
      ),
    );
  }
}
