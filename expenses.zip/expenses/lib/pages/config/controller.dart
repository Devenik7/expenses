import 'package:expenses/base.dart';
import 'package:expenses/pages/add_family/page.dart';
import 'package:expenses/pages/home/page.dart';
import 'package:get/get.dart';

class ConfigController extends GetxController {
  @override
  void onInit() async {
    super.onInit();

    if (!await Auth.init()) {
      await Auth.logout();
      return;
    }
    await Preferences.init();

    if (!Preferences.familyPopupShown) {
      bool familyPopup = await AddFamily.start() ?? false;
      Preferences.familyPopupShown = true;
      if (!familyPopup) Home.start();
    } else
      Home.start();
  }
}
