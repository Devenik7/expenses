import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'package:expenses/base.dart';
import 'package:expenses/pages/login/page.dart';

class Auth {
  static Future<bool> login() => (kIsWeb ? _loginWeb : _loginNative)();

  static Future<bool> _loginNative() async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      final GoogleSignInAuthentication? googleAuth =
          await googleUser?.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _loginWeb() async {
    try {
      GoogleAuthProvider googleProvider = GoogleAuthProvider()
        ..addScope('https://www.googleapis.com/auth/contacts.readonly');
      await FirebaseAuth.instance.signInWithRedirect(googleProvider);
      return true;
    } catch (_) {
      return false;
    }
  }

  static Stream<User?> get stateChanges =>
      FirebaseAuth.instance.authStateChanges();

  static Future<bool> init() async {
    var user = await UserService.instance.saveUser(
      FirebaseAuth.instance.currentUser!,
    );
    if (user == null) return false;
    currentUser = user;
    return true;
  }

  static late AppUser currentUser;

  static String get uid => currentUser.uid;

  static String get displayName => currentUser.name;

  static String get email => currentUser.email;

  static String get photoUrl => currentUser.photoUrl;

  static bool get hasFamily => currentUser.familyID.isNotNullOrEmpty;

  static Future<void> logout() async {
    try {
      await GoogleSignIn().disconnect();
    } catch (_) {}
    await FirebaseAuth.instance.signOut();
    Login.start();
  }
}
