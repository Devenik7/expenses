import 'package:flutter/material.dart';

import 'package:expenses/base.dart';

class SwitchFormField extends AppFormField<bool> {
  final TextDirection direction;
  final EdgeInsets? margin;

  SwitchFormField({
    Key? key,
    String? label,
    this.direction = TextDirection.ltr,
    this.margin = const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    FormFieldChangeCallback<bool>? onChange,
    FormFieldController<bool>? controller,
  }) : super(
          key: key,
          label: label,
          onChange: onChange,
          controller: controller,
        );

  @override
  SwitchFormFieldState createState() => SwitchFormFieldState();
}

class SwitchFormFieldState extends AppFormFieldState<bool> {
  @override
  SwitchFormField get widget => super.widget as SwitchFormField;

  void onTap([bool? update]) async {
    bool value =
        update != null ? update : !(effectiveController?.value ?? false);
    widget.onChange?.call(value);
    didChange(value);
  }

  Widget get text {
    if (widget.label.isNullOrEmpty) return SizedBox.shrink();
    return Text(
      widget.label!,
      style: TextStyle(fontWeight: FontWeight.bold),
    );
  }

  Widget get switchBtn => Switch.adaptive(
      value: effectiveController?.value ?? false, onChanged: onTap);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.translucent,
      child: Container(
        margin:
            widget.margin?.copyWith(right: (widget.margin?.right ?? 0) - 12),
        child: Row(
          textDirection: widget.direction,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            text,
            if (widget.label.isNotNullOrEmpty) SizedBox(width: 16),
            switchBtn
          ],
        ),
      ),
    );
  }
}
