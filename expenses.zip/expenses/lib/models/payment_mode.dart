import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:expenses/base.dart';

class PaymentMode extends BaseFirestoreModel {
  final String name;
  final String userID;

  PaymentMode({
    required this.name,
    required this.userID,
    required String uid,
    required Timestamp createdAt,
    required String createdBy,
    required bool active,
  }) : super(
          uid: uid,
          createdAt: createdAt,
          createdBy: createdBy,
          active: active,
        );

  factory PaymentMode.create(String name) {
    return PaymentMode(
      uid: '',
      name: name,
      userID: Auth.uid,
      createdBy: Auth.uid,
      createdAt: Timestamp.now(),
      active: true,
    );
  }

  PaymentMode copyWith({
    String? userID,
    String? name,
    String? uid,
    Timestamp? createdAt,
    String? createdBy,
    bool? active,
  }) {
    return PaymentMode(
      name: name ?? this.name,
      userID: userID ?? this.userID,
      uid: uid ?? this.uid,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
      active: active ?? this.active,
    );
  }

  Map<String, dynamic> toMap() =>
      {'userID': userID, 'name': name, ...super.toMap()};

  factory PaymentMode.fromMap(Map<String, dynamic> map, String uid) {
    return PaymentMode(
      name: map['name'] ?? '',
      userID: map['userID'] ?? '',
      uid: uid,
      createdAt: map['createdAt'],
      createdBy: map['createdBy'],
      active: map['active'],
    );
  }

  @override
  PaymentMode copyWithUid(String uid) => this.copyWith(uid: uid);
}
