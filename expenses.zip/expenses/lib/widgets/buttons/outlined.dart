import 'package:expenses/base.dart';
import 'package:flutter/material.dart';

class AppOutlinedButton extends StatelessWidget {
  final String title;
  final IconData? icon;
  final bool disabled;
  final bool autoFocus;
  final VoidCallback? onTap;
  final VoidCallback? onLongTap;
  final EdgeInsets? margin;

  AppOutlinedButton({
    required this.title,
    this.icon,
    this.onTap,
    this.onLongTap,
    this.disabled = false,
    this.autoFocus = false,
    this.margin = const EdgeInsets.symmetric(horizontal: 16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: margin,
      child: TextButton(
        onPressed: disabled ? null : onTap,
        onLongPress: disabled ? null : onLongTap,
        autofocus: autoFocus,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[Icon(icon), SizedBox(width: 12)],
            Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        style: ButtonStyle(
          visualDensity: VisualDensity.standard,
          shape: RoundedButtonBorder(),
          side: MaterialStateBorderSide.resolveWith(
            (states) => BorderSide(
                width: 1.5,
                color: states.contains(MaterialState.disabled)
                    ? Palette.grey
                    : Palette.accent),
          ),
          foregroundColor: MaterialStateColor.resolveWith((states) =>
              states.contains(MaterialState.disabled)
                  ? Palette.grey
                  : Palette.accent),
        ),
      ),
    );
  }
}
