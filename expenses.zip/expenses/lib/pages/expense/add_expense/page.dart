import 'package:expenses/base.dart';
import 'package:expenses/pages/expense/add_expense/controller.dart';
import 'package:expenses/widgets/chip.dart';
import 'package:expenses/widgets/form_fields/suggestion.dart';
import 'package:flutter/material.dart' hide TextFormField;
import 'package:get/get.dart';

class AddExpense extends AppPage {
  final controller = Get.put(AddExpenseController());

  @override
  String get title => 'Add an Expense';

  @override
  Widget? get body {
    return Column(
      children: [
        AppTextFormField(label: 'Name', controller: controller.name),
        SuggestionFormField(
          label: 'Category',
          suggestions: [
            'Groceries',
            'Two',
            'Three',
            'Two',
            'Three',
            'Two',
            'Three',
            'Two',
            'Three',
            'Two',
            'Three'
          ]
              .map<SearchableFormOption<String>>(
                (e) => SearchableFormOption<String>(
                  value: e,
                  build: (isAnswer, onTap) => AppChip(
                    label: e,
                    color: Colors.green.shade700,
                    icon: Icons.local_grocery_store_outlined,
                    onTap: onTap,
                    active: isAnswer,
                  ),
                  validate: (_) => e.toLowerCase().contains(_.toLowerCase()),
                ),
              )
              .toList(),
        ),
        AppTextFormField(label: 'Category', controller: controller.category),
        AppTextFormField(
            label: 'Price',
            keyboardType: TextInputType.number,
            controller: controller.price),
        AppTextFormField(
            label: 'Payment Mode', controller: controller.paymentMode),
        if (Auth.hasFamily) AppTextFormField(label: 'Owner'),
        SwitchFormField(
            label: 'Is this a recurring Expense ?',
            controller: controller.recurring),
        SwitchFormField(
            label: 'Was this vital ?', controller: controller.vital),
      ],
    );
  }

  @override
  Widget? get fab {
    return Obx(() {
      return FloatingActionButton(
        child: AnimatedSwitcher(
          duration: Duration(milliseconds: 150),
          child: controller.submitting.isTrue
              ? CircularLoader(color: Colors.white)
              : Icon(Icons.save_rounded),
        ),
        onPressed: controller.onSubmit,
        isExtended: true,
      );
    });
  }

  static String routeName = '/add_expense';

  static Future<bool?> start() => navigateTo<bool>(routeName);
}
