import 'package:get/get.dart';
import 'package:flutter/widgets.dart';

import 'package:expenses/base.dart';
import 'package:expenses/pages/splash/controller.dart';

class Splash extends AppPage {
  final controller = Get.put(SplashController());

  @override
  double get toolbarHeight => 0;

  @override
  Widget? get body => CircularLoader();

  static String routeName = '/splash';
}
