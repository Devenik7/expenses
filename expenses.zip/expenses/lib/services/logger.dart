class Logger {
  static bool _isEnabled = true;

  static void log(Object e, [StackTrace? trace]) {
    if (!_isEnabled) return;
    print('$e \n $trace');
  }
}
