import 'package:flutter/widgets.dart';

import 'package:expenses/base.dart';

class SectionHeader extends StatelessWidget {
  final String title;
  final IconData? actionIcon;
  final String actionTitle;
  final VoidCallback? onActionTap;
  final EdgeInsets? margin;

  SectionHeader({
    required this.title,
    this.actionIcon,
    this.actionTitle = '',
    this.onActionTap,
    this.margin = const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  });

  Widget get titleWidget =>
      Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20));

  Widget get action {
    if (actionIcon == null && actionTitle.isNotEmpty) return SizedBox.shrink();

    return GestureDetector(
      onTap: onActionTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (actionIcon != null) Icon(actionIcon, color: Palette.accent),
            if (actionIcon != null && actionTitle.isNotEmpty)
              SizedBox(width: 6),
            if (actionTitle.isNotEmpty)
              Text(actionTitle, style: TextStyle(color: Palette.accent)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [titleWidget, SizedBox(width: 12), action],
      ),
    );
  }
}
