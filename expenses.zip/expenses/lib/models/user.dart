import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:expenses/base.dart';

class AppUser extends BaseFirestoreModel {
  final String name;
  final String email;
  final String photoUrl;
  final String? nickName;
  final String? familyID;

  AppUser({
    required this.name,
    required this.email,
    required this.photoUrl,
    this.nickName,
    this.familyID,
    required String uid,
    required Timestamp createdAt,
    required String createdBy,
    required bool active,
  }) : super(
          uid: uid,
          createdAt: createdAt,
          createdBy: createdBy,
          active: active,
        );

  factory AppUser.newUser(String uid) {
    return AppUser(
      name: '',
      email: '',
      photoUrl: '',
      nickName: '',
      familyID: '',
      uid: uid,
      createdAt: Timestamp.now(),
      createdBy: uid,
      active: true,
    );
  }

  AppUser copyWith({
    String? name,
    String? email,
    String? photoUrl,
    String? nickName,
    String? familyID,
    String? uid,
    Timestamp? createdAt,
    String? createdBy,
    bool? active,
  }) {
    return AppUser(
      name: name ?? this.name,
      email: email ?? this.email,
      photoUrl: photoUrl ?? this.photoUrl,
      nickName: nickName ?? this.nickName,
      familyID: familyID ?? this.familyID,
      uid: uid ?? this.uid,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
      active: active ?? this.active,
    );
  }

  factory AppUser.fromMap(Map<String, dynamic> map, String uid) {
    return AppUser(
      name: map['name'],
      email: map['email'],
      photoUrl: map['photoUrl'],
      nickName: map['nickName'],
      familyID: map['familyID'],
      uid: uid,
      createdAt: map['createdAt'],
      createdBy: map['createdBy'],
      active: map['active'],
    );
  }

  @override
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'photoUrl': photoUrl,
      'nickName': nickName,
      'familyID': familyID,
      ...super.toMap(),
    };
  }

  @override
  BaseFirestoreModel copyWithUid(String uid) => this.copyWith(uid: uid);
}
