import 'package:flutter/widgets.dart';

enum ValidationResult { success, warning, error }

class Validation {
  final ValidationResult result;
  final String message;

  Validation({required this.result, required this.message});

  Validation.success() : this(result: ValidationResult.success, message: '');

  Validation.error(String error)
      : this(result: ValidationResult.error, message: error);

  Validation.warning(String message)
      : this(result: ValidationResult.warning, message: message);

  bool get isSuccess => result == ValidationResult.success;

  bool get isWarning => result == ValidationResult.warning;

  bool get isError => result == ValidationResult.error;
}

typedef FormFieldChangeCallback<T> = void Function(T? value);

class FormOption<T> {
  final T value;
  final Widget Function(bool isAnswer, VoidCallback onTap) build;

  FormOption({required this.value, required this.build});
}

class SearchableFormOption<T> extends FormOption<T> {
  final bool Function(String) validate;

  SearchableFormOption({
    required T value,
    required Widget Function(bool isAnswer, VoidCallback onTap) build,
    required this.validate,
  }) : super(value: value, build: build);
}

class FormFieldController<T> extends ValueNotifier<T?> {
  FormFieldController({T? value}) : super(value);
}

class AppFormField<T> extends FormField<T> {
  final String? label;
  final String hint;
  final bool optional;
  final FormFieldChangeCallback<T>? onChange;
  final FormFieldController<T>? controller;

  AppFormField({
    Key? key,
    this.label,
    this.hint = '',
    this.optional = false,
    this.onChange,
    this.controller,
  }) : super(key: key, builder: (_) => Container());

  @override
  AppFormFieldState<T> createState() => AppFormFieldState<T>();
}

class AppFormFieldState<T> extends FormFieldState<T> {
  late FormFieldController<T>? _controller;

  @override
  AppFormField<T> get widget => super.widget as AppFormField<T>;

  FormFieldController<T>? get effectiveController =>
      widget.controller ?? _controller;

  bool get hasAnswer => effectiveController?.value != null;

  @override
  void initState() {
    super.initState();

    if (widget.controller == null)
      _controller = FormFieldController(value: widget.initialValue);
    else
      widget.controller!.addListener(_handleControllerChanged);
  }

  void _handleControllerChanged() {
    if (effectiveController!.value != null)
      didChange(effectiveController!.value);
  }

  @override
  void didUpdateWidget(covariant AppFormField<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.controller != oldWidget.controller) {
      oldWidget.controller?.removeListener(_handleControllerChanged);
      widget.controller?.addListener(_handleControllerChanged);

      if (oldWidget.controller != null && widget.controller == null)
        _controller = FormFieldController(value: oldWidget.controller!.value);
      if (widget.controller != null) {
        setValue(widget.controller!.value);
        if (oldWidget.controller == null) _controller = null;
      }
    }
  }

  @override
  void dispose() {
    widget.controller?.removeListener(_handleControllerChanged);
    super.dispose();
  }

  @override
  void didChange(T? value) {
    super.didChange(value);
    if (effectiveController!.value != value) effectiveController!.value = value;
  }

  void clear() {
    widget.onChange?.call(null);
    didChange(null);
  }

  @override
  void reset() {
    effectiveController!.value = widget.initialValue;
    super.reset();
  }
}
