import 'package:get/get.dart';
import 'package:flutter/material.dart';

import 'package:expenses/base.dart';
import 'package:expenses/pages/profile/controller.dart';

class Profile extends StatelessWidget {
  final controller = Get.put(ProfileController());

  Widget get switchBtn => SwitchFormField(
      label: 'Enable Notifications',
      controller: controller.enableNotificationsController);

  Widget get logoutButton => AppOutlinedButton(
      title: 'Logout', icon: Icons.logout_rounded, onTap: Auth.logout);

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      children: [UserTile(), FamilyTile(), switchBtn, logoutButton],
    );
  }
}
