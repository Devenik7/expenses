import 'package:get/get.dart';
import 'package:flutter/material.dart';

void showSnack(String title, {Color? color}) {
  var scaffold = ScaffoldMessenger.maybeOf(Get.context!);
  scaffold != null
      ? scaffold.showSnackBar(SnackBar(
          content: Text(title),
          backgroundColor: color,
        ))
      : Get.snackbar(title, '');
}
