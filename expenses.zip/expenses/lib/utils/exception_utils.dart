T? tryer<T>(T Function() tryer) {
  try {
    return tryer();
  } catch (_) {
    return null;
  }
}

T tryCatcher<T>(T Function() tryer, T defaultVal) {
  try {
    T val = tryer();
    return val;
  } catch (_) {
    return defaultVal;
  }
}
