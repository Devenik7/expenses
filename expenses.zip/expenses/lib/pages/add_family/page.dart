import 'package:expenses/base.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class AddFamily extends AppPage {
  @override
  double get toolbarHeight => 0;

  @override
  Widget? get body {
    return Center(
      child: Column(
        children: [
          Text('Want to add a family ?'),
          SizedBox(height: 8),
          GestureDetector(
            onTap: () => Get.back<bool>(result: false),
            child: Text('I\'ll do this later'),
          ),
        ],
      ),
    );
  }

  static String routeName = '/add-family';

  static Future<bool?>? start() => navigateTo<bool>(routeName);
}
