import 'package:shared_preferences/shared_preferences.dart';

class Preferences {
  static late SharedPreferences instance;

  static Future<void> init() async {
    instance = await SharedPreferences.getInstance();
  }

  static bool get familyPopupShown => instance.getBool('family_popup') ?? false;

  static set familyPopupShown(bool value) =>
      instance.setBool('family_popup', value);
}
