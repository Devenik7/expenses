import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:expenses/base.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserService extends BaseFirestoreService<AppUser> {
  UserService._();

  static UserService? _instance;

  static UserService get instance {
    if (_instance == null) _instance = UserService._();
    return _instance!;
  }

  Future<AppUser?> saveUser(User user) async {
    try {
      var userSnap = await ref.doc(user.uid).get();
      var userToSave = (userSnap.exists
              ? AppUser.fromMap(
                  userSnap.data() as Map<String, dynamic>, user.uid)
              : AppUser.newUser(user.uid))
          .copyWith(
              name: user.displayName,
              email: user.email,
              photoUrl: user.photoURL);

      await ref.doc(user.uid).set(userToSave.toMap());
      return userToSave;
    } catch (_, __) {
      Logger.log(_, __);
      return null;
    }
  }

  @override
  CollectionReference<Object?> get ref =>
      FirebaseFirestore.instance.collection('users');

  @override
  AppUser construct(Map<String, dynamic> map, String uid) =>
      AppUser.fromMap(map, uid);
}
