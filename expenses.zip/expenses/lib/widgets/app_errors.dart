import 'package:expenses/base.dart';
import 'package:flutter/widgets.dart';

class AppError extends StatelessWidget {
  final String title;
  final String actionTitle;
  final VoidCallback? onTap;

  AppError({required this.title, this.actionTitle = 'Try Again', this.onTap});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Text(title),
          if (onTap != null) AppOutlinedButton(title: actionTitle, onTap: onTap)
        ],
      ),
    );
  }
}
