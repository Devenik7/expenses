import 'package:expenses/base.dart';
import 'package:expenses/pages/config/controller.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class Config extends AppPage {
  final controller = Get.put(ConfigController());

  @override
  double get toolbarHeight => 0;

  @override
  Widget? get body => Center(child: CircularLoader());

  static String routeName = '/config';

  static void start() => navigateOffAll(routeName);
}
