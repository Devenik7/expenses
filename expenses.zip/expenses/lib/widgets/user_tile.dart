import 'package:flutter/material.dart';

import 'package:expenses/base.dart';

class UserTile extends StatelessWidget {
  final AppUser? user;
  final bool showUserSince;
  final EdgeInsets? margin;

  UserTile({
    this.user,
    this.showUserSince = true,
    this.margin = const EdgeInsets.all(16),
  });

  Widget get avtar {
    String? image = user == null ? Auth.photoUrl : user?.photoUrl;
    return CircleAvatar(
      radius: 24,
      backgroundColor: Palette.grey,
      child: Icon(Icons.person_rounded, color: Colors.white),
      foregroundImage: image.isNotNullOrEmpty ? NetworkImage(image!) : null,
    );
  }

  Widget get content {
    String? email = user == null ? Auth.email : user!.email;
    String? name = user == null ? Auth.displayName : user!.name;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(height: 3),
        Text(name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 4),
        Text(email),
        userSince,
      ],
    );
  }

  Widget get userSince {
    String? userSince =
        (user == null ? Auth.currentUser.createdAt : user!.createdAt)
            .toDate()
            .format('MMM d, yyyy');

    if (!showUserSince || userSince.isNullOrEmpty) return SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.only(top: 4),
      child: Text(
        'User since $userSince',
        style: TextStyle(fontSize: 10, color: Palette.grey),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [avtar, SizedBox(width: 12), Expanded(child: content)],
      ),
    );
  }
}
