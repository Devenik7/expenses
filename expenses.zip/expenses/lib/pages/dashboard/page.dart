import 'package:expenses/base.dart';
import 'package:expenses/pages/dashboard/controller.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class Dashboard extends StatelessWidget {
  final controller = Get.put(DashboardController());

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Expense>>(
      stream: ExpenseService.instance.myExpenses,
      builder: (_, snapshot) {
        if (snapshot.hasData)
          return ListView.builder(
            itemBuilder: (_, i) => Text(snapshot.data![i].name),
            itemCount: snapshot.data!.length,
          );
        else if (snapshot.hasError)
          return Text('Error Fetching Expenses - ${snapshot.error}',
              maxLines: 2, overflow: TextOverflow.ellipsis);
        else
          return CircularLoader();
      },
    );
  }
}
