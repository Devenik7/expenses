import 'package:expenses/pages/login/controller.dart';
import 'package:expenses/services/navigation.dart';
import 'package:expenses/widgets/page.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class Login extends AppPage {
  final controller = Get.put(LoginController());

  @override
  double get toolbarHeight => 0;

  @override
  Widget? get body {
    return Center(
      child:
          GestureDetector(onTap: controller.onLoginTap, child: Text('Login')),
    );
  }

  static String routeName = '/login';

  static void start() => navigateOffAll(routeName);
}
