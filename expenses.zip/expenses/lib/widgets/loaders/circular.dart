import 'package:flutter/material.dart';

class CircularLoader extends StatelessWidget {
  final Color? color;

  CircularLoader({this.color});

  @override
  Widget build(BuildContext context) =>
      Center(child: CircularProgressIndicator(color: color));
}
