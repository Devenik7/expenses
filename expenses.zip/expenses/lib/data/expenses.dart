import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:expenses/base.dart';

class ExpenseService extends BaseFirestoreService<Expense> {
  ExpenseService._();

  static ExpenseService? _instance;

  static ExpenseService get instance {
    if (_instance == null) _instance = ExpenseService._();
    return _instance!;
  }

  Stream<List<Expense>> get myExpenses => ref
      .where('owner', isEqualTo: Auth.uid)
      .snapshots()
      .map((event) => event.docs
          .map((doc) => construct(doc.data() as Map<String, dynamic>, doc.id))
          .toList());

  @override
  Expense construct(Map<String, dynamic> map, String uid) =>
      Expense.fromMap(map, uid);

  @override
  CollectionReference<Object?> get ref =>
      FirebaseFirestore.instance.collection('expenses');
}
