import 'dart:async';

import 'package:expenses/pages/config/page.dart';
import 'package:expenses/base.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  void onLoginTap() async {
    if (await Auth.login())
      Config.start();
    else
      Get.snackbar('Error', 'Failed to Login. Please retry');
  }
}
