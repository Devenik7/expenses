import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:expenses/base.dart';

class PaymentModeService extends BaseFirestoreService<PaymentMode> {
  PaymentModeService._();

  static PaymentModeService? _instance;

  static PaymentModeService get instance {
    if (_instance == null) _instance = PaymentModeService._();
    return _instance!;
  }

  Future<List<PaymentMode>> fetchModesForUser([String? userID]) async {
    try {
      var response =
          await ref.where('userID', isEqualTo: userID ?? Auth.uid).get();
      return response.docs
          .map((e) =>
              PaymentMode.fromMap(e.data() as Map<String, dynamic>, e.id))
          .toList();
    } catch (_, __) {
      Logger.log(_, __);
      return [];
    }
  }

  @override
  CollectionReference<Object?> get ref =>
      FirebaseFirestore.instance.collection('payment_modes');

  @override
  PaymentMode construct(Map<String, dynamic> map, String uid) =>
      PaymentMode.fromMap(map, uid);
}
