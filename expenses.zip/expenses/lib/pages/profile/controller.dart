import 'package:expenses/widgets/form_fields/utils.dart';
import 'package:get/get.dart';

class ProfileController extends GetxController {
  final enableNotificationsController = FormFieldController<bool>(value: false);
}
