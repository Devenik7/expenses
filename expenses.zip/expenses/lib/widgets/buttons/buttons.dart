export 'elevated.dart';
export 'outlined.dart';

import 'package:flutter/material.dart';

class RoundedButtonBorder extends RoundedRectangleBorder
    implements MaterialStateOutlinedBorder {
  @override
  OutlinedBorder? resolve(Set<MaterialState> states) {
    return RoundedRectangleBorder(borderRadius: BorderRadius.circular(8));
  }
}
