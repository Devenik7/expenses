import 'package:expenses/base.dart';
import 'package:expenses/resources/palette.dart';
import 'package:flutter/material.dart';

class AppElevatedButton extends StatelessWidget {
  final String title;
  final IconData? icon;
  final bool disabled;
  final bool autoFocus;
  final VoidCallback? onTap;
  final VoidCallback? onLongTap;
  final EdgeInsets? margin;

  AppElevatedButton({
    required this.title,
    this.icon,
    this.onTap,
    this.onLongTap,
    this.disabled = false,
    this.autoFocus = false,
    this.margin = const EdgeInsets.symmetric(horizontal: 16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: margin,
      child: TextButton(
        onPressed: disabled ? null : onTap,
        onLongPress: disabled ? null : onLongTap,
        autofocus: autoFocus,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, color: Colors.white),
              SizedBox(width: 12)
            ],
            Text(title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                )),
          ],
        ),
        style: ButtonStyle(
          visualDensity: VisualDensity.standard,
          shape: RoundedButtonBorder(),
          backgroundColor: MaterialStateColor.resolveWith((states) =>
              states.contains(MaterialState.disabled)
                  ? Palette.btnDisabled
                  : Palette.btnActive),
        ),
      ),
    );
  }
}
